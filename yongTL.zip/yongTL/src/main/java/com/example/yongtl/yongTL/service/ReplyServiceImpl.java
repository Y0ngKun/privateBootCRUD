package com.example.yongtl.yongTL.service;

import com.example.yongtl.yongTL.dao.BoardDAO;
import com.example.yongtl.yongTL.dao.ReplyDAO;
import com.example.yongtl.yongTL.dto.ReplyRequestDTO;
import com.example.yongtl.yongTL.entity.Board;
import com.example.yongtl.yongTL.entity.Reply;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReplyServiceImpl implements ReplyService {

    /*의존성 주입 시작*/
    private final ReplyDAO replyDAO;
    private final BoardDAO boardDAO;
    /*의존성 주입 끝*/

    @Transactional
    @Override
    public void replySave(Long bno, ReplyRequestDTO dto) {
        Board board = boardDAO.findById(bno).orElseThrow(() -> new IllegalArgumentException(bno+"게시글이 존재 하지 않습니다."));
        dto.setBoard(board);

        Reply reply = dto.toEntity();
        replyDAO.save(reply);
    }

    @Override
    public Reply saveMyEntity(Reply reply) {
        return replyDAO.save(reply);
    }

    @Override
    public List<Reply> getAllEntities() {
        return null;
    }

    @Override
    public Reply getEntityById(Long rno) {
        return null;
    }

    @Override
    public Reply updateEntity(Long rno, Reply reply) {
        return null;
    }

    @Override
    public void deleteEntity(Long rno) {

    }

    @Override
    public Page<Reply> list(int page) {
        return null;
    }
}
