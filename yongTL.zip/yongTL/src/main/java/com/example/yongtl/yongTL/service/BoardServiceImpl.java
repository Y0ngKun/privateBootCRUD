package com.example.yongtl.yongTL.service;

import com.example.yongtl.yongTL.dao.BoardDAO;
import com.example.yongtl.yongTL.entity.Board;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BoardServiceImpl implements BoardService {

    private final BoardDAO boardDAO;
    @Autowired
    public BoardServiceImpl(BoardDAO boardDAO) {
        this.boardDAO = boardDAO;
    }

    // CREATE (저장)
    public Board saveMyEntity(Board board) {
        return boardDAO.save(board);
    }

    // READ (조회)
    public List<Board> getAllEntities() {

        return boardDAO.findAll(Sort.by(Sort.Direction.DESC,"bno"));
    }

    public Board getEntityById(Long bno) {
        Optional<Board> optionalBoard = boardDAO.findById(bno);
        return optionalBoard.orElse(null);
    }

    // UPDATE (수정)
    public Board updateEntity(Long bno, Board board) {

        Optional<Board> optionalMyEntity = boardDAO.findById(bno);

        if (optionalMyEntity.isPresent()) {
            Board existingEntity = optionalMyEntity.get();
            existingEntity.setWriter(board.getWriter());
            existingEntity.setTitle(board.getTitle());
            existingEntity.setContent(board.getContent());
            return boardDAO.save(existingEntity);
        } else {
            return null;
        }
    }

    // DELETE (삭제)
    public void deleteEntity(Long bno) {
        boardDAO.deleteById(bno);
    }

    //게시글 페이징 처리
    public Page<Board> list(int page) {
        return boardDAO.findAll(PageRequest.of(page, 10, Sort.by(Sort.Direction.DESC, "bno")));
    }

}//Class BoardServiceImpl;
