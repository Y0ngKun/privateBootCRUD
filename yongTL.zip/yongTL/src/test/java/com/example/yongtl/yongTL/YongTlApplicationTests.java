package com.example.yongtl.yongTL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YongTlApplicationTests {

	@Test
	void contextLoads() {
	}

}
