package com.example.yongtl.yongTL.controller;

import com.example.yongtl.yongTL.entity.Board;
import com.example.yongtl.yongTL.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@RestController
@RequestMapping("/board")
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;

    /*Create 시작*/
    @PostMapping("/write")
    public ModelAndView write(Board board){
        ModelAndView mav = new ModelAndView();
        boardService.saveMyEntity(board);
        mav.setView(new RedirectView("/board/list",true));
        return mav;
    }
    /*Create 끝*/
    
    /*Read 시작*/
    @GetMapping("/write")
    public ModelAndView write(){
        ModelAndView mav = new ModelAndView();
        mav.setViewName("board/write");
        return mav;
    }

    @GetMapping("/list")
    public ModelAndView listPaging(@RequestParam(required = false,defaultValue = "0", value = "page") int page){
        ModelAndView mav  = new ModelAndView();

        Page<Board> listPage = boardService.list(page);
        int totalPage = listPage.getTotalPages();

        mav.addObject("boardList", listPage.getContent());
        mav.addObject("totalPage",totalPage);

        mav.setViewName("board/board");
        return mav;
    }
    //게시글 상세보기
    @GetMapping(value = "/list/{bno}")
    public ModelAndView viewArticle(@PathVariable("bno") Long bno ) {
        ModelAndView mav = new ModelAndView();
//        BoardResponseDTO dto = new BoardResponseDTO(boardService.getEntityById(bno));
//        List<ReplyResponseDTO> replyList = dto.getReplyList();

        mav.addObject("article",boardService.getEntityById(bno));
//        mav.addObject("replyList",replyList);
        mav.setViewName("board/details");
        return mav;
    }
    /*Read 끝*/



    /*Update 시작*/
    @GetMapping("/edit/{bno}")
    public ModelAndView articleEdit(@PathVariable("bno") Long bno){
        ModelAndView mav = new ModelAndView();
        mav.addObject("article", boardService.getEntityById(bno));
        mav.setViewName("/board/edit");
        return  mav;
    }
    @PostMapping("/edit/{bno}")
    public ModelAndView editPostBno(@PathVariable("bno")Long bno, Board board){
        ModelAndView mav = new ModelAndView();
        board.setWriter(board.getWriter());
        board.setContent(board.getContent());
        board.setTitle(board.getTitle());
        boardService.updateEntity(bno,board);
        mav.setView(new RedirectView("/board/list", true));
        return mav;
    }
    /*Update 끝*/

    /*delete 시작*/
    @GetMapping("/delete/{bno}")
    public ModelAndView deleteArticle (@PathVariable("bno") Long bno){
        ModelAndView mav = new ModelAndView();
        boardService.deleteEntity(bno);
        mav.setView(new RedirectView("/board/list",true));
        return  mav;
    }
    /*delete 끝*/

}
