package com.example.yongtl.yongTL.dto;

import com.example.yongtl.yongTL.entity.Reply;
import lombok.Getter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Getter
public class ReplyResponseDTO {
    private Long rno;
    private String rcontent;
    private String rwriter;
    private String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"));
    private String modifiedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"));
    private Long bno;

    public ReplyResponseDTO (Reply reply){
        this.rno = reply.getRno();
        this.rcontent = reply.getRcontent();
        this.rwriter = reply.getRwriter();
        this.createdDate = reply.getCreatedDate();
        this.modifiedDate = reply.getModifiedDate();
        this.bno = reply.getBoard().getBno();
    }
}
