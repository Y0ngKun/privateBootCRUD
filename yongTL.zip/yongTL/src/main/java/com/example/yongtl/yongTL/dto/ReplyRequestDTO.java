package com.example.yongtl.yongTL.dto;

import com.example.yongtl.yongTL.entity.Board;
import com.example.yongtl.yongTL.entity.Reply;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReplyRequestDTO {
    private Long rno;
    private String rcontent;
    private String rwriter;
    private String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"));
    private String modifiedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"));
    private Board board;

    /* DTO에서 entity로 */
    public Reply toEntity (){
        Reply replyEntity = Reply.builder()
                .rno(rno)
                .rcontent(rcontent)
                .rwriter(rwriter)
                .createdDate(createdDate)
                .modifiedDate(modifiedDate)
                .board(board)
                .build();
        return replyEntity;
    }



}
