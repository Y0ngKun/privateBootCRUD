package com.example.yongtl.yongTL.dto;

import com.example.yongtl.yongTL.entity.Board;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public class BoardResponseDTO {

    private Long bno;
    private String title;
    private String writer;
    private String content;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<ReplyResponseDTO> replyList;

    public BoardResponseDTO (Board board){
        this.bno = board.getBno();
        this.title = board.getTitle();
        this.writer = board.getWriter();
        this.content = board.getContent();
        this.createdAt = board.getCreatedAt();
        this.updatedAt = board.getUpdatedAt();
        this.replyList = board.getReplyList().stream().map(ReplyResponseDTO::new).collect(Collectors.toList());

    }
}
