package com.example.yongtl.yongTL.service;

import com.example.yongtl.yongTL.dto.ReplyRequestDTO;
import com.example.yongtl.yongTL.entity.Reply;
import org.springframework.data.domain.Page;

import java.util.List;

public interface ReplyService {

    // CREATE (저장)
    public Reply saveMyEntity(Reply reply);

    //댓글 저장
    public void replySave(Long rno, ReplyRequestDTO replyRequestDTO);

    // READ (조회)
    public Reply getEntityById(Long rno);
    public List<Reply> getAllEntities();

    // UPDATE (수정)
    public Reply updateEntity(Long rno, Reply reply);

    // DELETE (삭제)
    public void deleteEntity(Long rno);

    //게시글 페이징 처리
    public Page<Reply> list(int page);

}
