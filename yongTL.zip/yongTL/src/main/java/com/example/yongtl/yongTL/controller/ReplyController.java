package com.example.yongtl.yongTL.controller;

import com.example.yongtl.yongTL.dto.ReplyRequestDTO;
import com.example.yongtl.yongTL.service.BoardService;
import com.example.yongtl.yongTL.service.ReplyService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@RestController
@RequestMapping("/reply")
@AllArgsConstructor
public class ReplyController {

    @Autowired
    private final ReplyService replyService;
    @Autowired
    private final BoardService boardService;


    @PostMapping("/saveReply/{bno}")
    public ModelAndView saveReply (@PathVariable("bno") Long bno, ReplyRequestDTO dto){
        ModelAndView mav = new ModelAndView();

        replyService.replySave(bno,dto);

        mav.setView(new RedirectView("/board/list/"+bno, true));

        return mav;
    }



}
