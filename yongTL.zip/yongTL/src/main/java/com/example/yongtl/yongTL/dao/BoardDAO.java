package com.example.yongtl.yongTL.dao;

import com.example.yongtl.yongTL.entity.Board;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoardDAO extends JpaRepository<Board , Long> {

}
