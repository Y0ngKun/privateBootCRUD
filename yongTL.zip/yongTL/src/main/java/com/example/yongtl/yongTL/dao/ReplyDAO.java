package com.example.yongtl.yongTL.dao;

import com.example.yongtl.yongTL.entity.Reply;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ReplyDAO extends JpaRepository<Reply, Long> {

}
