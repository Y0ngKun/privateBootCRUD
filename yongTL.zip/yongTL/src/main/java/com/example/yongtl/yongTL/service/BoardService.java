package com.example.yongtl.yongTL.service;

import com.example.yongtl.yongTL.entity.Board;
import org.springframework.data.domain.Page;

import java.util.List;

public interface BoardService {

    // CREATE (저장)
    public Board saveMyEntity(Board board);

    // READ (조회)
    public List<Board> getAllEntities();

    public Board getEntityById(Long bno);

    // UPDATE (수정)
    public Board updateEntity(Long bno, Board board);

    // DELETE (삭제)
    public void deleteEntity(Long bno);

    //게시글 페이징 처리
    public Page<Board> list(int page);

}
